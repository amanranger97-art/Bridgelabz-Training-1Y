package Generics_Collections.Generic;
import java.util.*;

public class CopyListElements {

    public static void copyList(List<? super Number> dest, List<? extends Number> src) {

        for (Number num : src) {
            dest.add(num);
        }
    }

    public static void main(String[] args) {

        List<Integer> src = Arrays.asList(1, 2, 3);

        List<Number> dest = new ArrayList<>();

        copyList(dest, src);

        System.out.println("After Copy: " + dest);
    }
}